#include "Firework.h"
#include <math.h>  
 GLfloat Firework::GRAVITY = 0.05f;
 GLfloat Firework::baselineYSpeed = -4.0f;
 GLfloat Firework::maxYSpeed = -4.0f;

 ///////////////////////////////////////////////

Firework::Firework()
{
	initialise();
}

///////////////////////////////////////////////

void Firework::initialise()
{
	float xLoc = ((float)rand() / (float)RAND_MAX) * 1366.0f;
	float xSpeedVal = -2 + ((float)rand() / (float)RAND_MAX) * 4.0f;
	float ySpeedVal = baselineYSpeed + ((float)rand() / (float)RAND_MAX) * maxYSpeed;
	for (int loop = 0; loop < FIREWORK_PARTICLES; loop++)
	{
		x[loop] = xLoc;
		y[loop] = 778.0f; 
		xSpeed[loop] = xSpeedVal;
		ySpeed[loop] = ySpeedVal;
	}
	red = ((float)rand() / (float)RAND_MAX);
	green = ((float)rand() / (float)RAND_MAX);
	blue = ((float)rand() / (float)RAND_MAX);
	alpha = 1.0f;
	LaunchTime = ((int)rand() % 400);
	particleSize = 1.0f + ((float)rand() / (float)RAND_MAX) * 3.0f;
	hasExploded = false;
}

///////////////////////////////////////////////

void Firework::move()
{
	if (LaunchTime <= 0)
	{
		for (int loop = 0; loop < FIREWORK_PARTICLES; loop++)
		{
				x[loop] += xSpeed[loop];
				y[loop] += ySpeed[loop];
				ySpeed[loop] += Firework::GRAVITY;
		}
	}
	else
	{
		LaunchTime--;
	}
	if (ySpeed[0] > 0.0f)
	{
		for (int loop2 = 0; loop2 < FIREWORK_PARTICLES; loop2++)
		{
			float rndx = -4 + (rand() / (float)RAND_MAX) * 8;
			float rndy = -4 + (rand() / (float)RAND_MAX) * 8;
			float length = sqrt(rndx*rndx + rndy*rndy);
			xSpeed[loop2] = (rndx/length) * (3.0f + (float)((rand() % 4)/10.0f));
			ySpeed[loop2] = (rndy/length) * (3.0f + (float)((rand() % 4)/10.0f));
		}
		hasExploded = true;
	}
}

///////////////////////////////////////////////

void Firework::explode()
{
	for (int loop = 0; loop < FIREWORK_PARTICLES; loop++)
	{
		xSpeed[loop] *= 0.99;
		x[loop] += xSpeed[loop];
		y[loop] += ySpeed[loop];
		ySpeed[loop] += Firework::GRAVITY;
	}

	if (alpha > 0.0f)
	{
		alpha -= 0.01f;
	}
	else 
	{
		initialise();
	}
}