////////////////////////////////////////////////////////////////
// School of Computer Science
// The University of Manchester
//
// This code is licensed under the terms of the Creative Commons 
// Attribution 2.0 Generic (CC BY 3.0) License.
//
// Skeleton code for COMP37111 coursework, 2012-13
//
// Authors: Arturs Bekasovs and Toby Howard
//
/////////////////////////////////////////////////////////////////
#include <ctime>
#include <time.h>         // Needed to seed the random number generator
#include <windows.h>      //This must come before gl.h 
#include "Firework.h"    // Include  fireworks class
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
GLint windowWidth = 1366; // Define our window width
GLint windowHeight = 768; // Define our window height
const int FIREWORKS = 15; // Number of fireworks
// Array of fireworks
Firework fireW[FIREWORKS];


#ifdef MACOSX
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

///////////////////////////////////////////////

void drawScene()
{
	glAccum(GL_RETURN, 1.0f);
	glClear(GL_ACCUM_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0.375, 0.375, 0);
	// Drawfireworks
	for (int loop = 0; loop < FIREWORKS; loop++)
	{
		for (int particleLoop = 0; particleLoop < FIREWORK_PARTICLES; particleLoop++)
		{
			glPointSize(fireW[loop].particleSize);
			glBegin(GL_POINTS);
			glColor4f(fireW[loop].red, fireW[loop].green, fireW[loop].blue, fireW[loop].alpha);
			glVertex2f(fireW[loop].x[particleLoop], fireW[loop].y[particleLoop]);
			glEnd();
		}
		if (fireW[loop].hasExploded == false)
		{
			fireW[loop].move();
		}
		else
		{
			fireW[loop].explode();
		}
	}
	glAccum(GL_ACCUM, 0.96f);
	glutSwapBuffers();
} 


 /////////////////////////////////////////////////

void display()
{
	glLoadIdentity();
	drawScene();
	glutSwapBuffers();
}

///////////////////////////////////////////////

void keyboard(unsigned char key, int x, int y)
{
	if (key == 27) exit(0);
	glutPostRedisplay();
}


///////////////////////////////////////////////

void ChangeParameters(int key, int x, int y)
{
	switch (key)
	{
	case GLUT_KEY_UP:
		if (fireW[0].baselineYSpeed  > -8.0f)
		{
			fireW[0].baselineYSpeed -= 0.05f;
			std::cout << "Baseline YSpeed: " << fireW[1].baselineYSpeed << std::endl;
		}
		else
		{
			std::cout << "top Baseline YSpeed reached" << std::endl;
		}
		break;
	case GLUT_KEY_DOWN:
		if (fireW[0].baselineYSpeed < -1.0f)
		{
			fireW[0].baselineYSpeed += 0.05f;
			std::cout << "Baseline YSpeed: " << fireW[1].baselineYSpeed << std::endl;
		}
		else
		{
			std::cout << "lowest Baseline YSpeed reached" << std::endl;
		}
		break;
	case GLUT_KEY_LEFT:
		if (fireW[0].GRAVITY > 0.01f)
		{
			fireW[0].GRAVITY -= 0.001f;
			std::cout << "Gravity: " << fireW[1].GRAVITY << std::endl;
		}
		else
		{
			std::cout << "lowest Gravity reached" << std::endl;
		}
		break;
	case GLUT_KEY_RIGHT:
		if (fireW[0].GRAVITY < 0.1f)
		{
			for (int loop = 0; loop < FIREWORKS; loop++)
				fireW[0].GRAVITY += 0.001f;
			std::cout << "Gravity: " << fireW[1].GRAVITY << std::endl;
		}
		else
		{
			std::cout << "Top Gravity reached" << std::endl;
		}
		break;
		
	}
}

///////////////////////////////////////////////

void reshape(int width, int height)
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glViewport(0, 0, (GLsizei)width, (GLsizei)height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, windowWidth, windowHeight, 0, 0, 1); 
	glMatrixMode(GL_MODELVIEW);
}

///////////////////////////////////////////////

void initGraphics(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitWindowSize(1366, 768);
	glutInitWindowPosition(120, 120);
	glutInitDisplayMode(GLUT_DOUBLE);
	glutCreateWindow("COMP37111 Fireworks");
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutSpecialUpFunc(ChangeParameters);
	glutReshapeFunc(reshape);
	glViewport(0, 0, (GLsizei)windowWidth, (GLsizei)windowHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, windowWidth, windowHeight, 0, 0, 1); 
	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glClearAccum(0.0f, 0.0f, 0.0f, 1.0f);
	glEnable(GL_POINT_SMOOTH); 
}

/////////////////////////////////////////////////

int main(int argc, char *argv[])
{
	srand((unsigned)time(NULL));
	initGraphics(argc, argv);
	glutIdleFunc(drawScene);
	glutMainLoop();
}