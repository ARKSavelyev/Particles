#pragma once
#ifndef FIREWORK_H
#define FIREWORK_H
#include <windows.h>
#include <cstdlib>
#include <GL/gl.h> 
#include <gl\glu.h>	
const int FIREWORK_PARTICLES = 120;

class Firework
{
	public:
		GLfloat x[FIREWORK_PARTICLES];
		GLfloat y[FIREWORK_PARTICLES];
		GLfloat xSpeed[FIREWORK_PARTICLES];
		GLfloat ySpeed[FIREWORK_PARTICLES];

		GLfloat red;
		GLfloat blue;
		GLfloat green;
		GLfloat alpha;

		int LaunchTime;
		GLfloat particleSize;
		bool hasExploded;
		static GLfloat baselineYSpeed;
		static GLfloat maxYSpeed;
		static GLfloat GRAVITY;
		Firework(); 
		void initialise();
		void move();
		void explode();
};

#endif